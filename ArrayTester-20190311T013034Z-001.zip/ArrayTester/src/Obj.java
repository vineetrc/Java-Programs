
public class Obj {
    private int value;
	
	public Obj(int value) {
		
		this.value=value;
		
		
		
		
		
		
	}
	public void increment() {
		
		this.value++;
		
	}
	
	public String toString() {
		
		
		return value+"";
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
}
